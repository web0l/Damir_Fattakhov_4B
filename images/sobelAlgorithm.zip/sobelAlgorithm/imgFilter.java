import javax.swing.*;
import java.awt.image.*;
import java.io.*;
import java.awt.*;
import javax.imageio.ImageIO;
import java.awt.geom.AffineTransform;



public class imgFilter {
    public static void main(String[] args){
        File file = new File("image.jpg");
        BufferedImage image = null;
        
        try {
            image = ImageIO.read(file);
        } catch (IOException e){
            e.printStackTrace(System.out);
        }
        if (image != null){
            //image = gaussianBlur(rotationMyself(grayScale(scale(image,5))));
            //display(gaussianBlur(pixelate(image,10)));
            display(sobel(blur(blur(blur(scaleMyself(image,8))))));
        }
    }
    
    
    public static BufferedImage sobel(BufferedImage img){
        BufferedImage edge = new BufferedImage(
        img.getWidth(), img.getHeight(), BufferedImage.TYPE_BYTE_GRAY);
        for (int x = 1; x<img.getWidth()-1; x++){
            for(int y = 1; y<img.getHeight()-1; y++){
                //Horizontal Edge Detection
                int horPixel = (img.getRGB(x-1, y-1) & 0xff) + (img.getRGB(x-1, y) & 0xff) * 2 + (img.getRGB(x-1, y+1) & 0xff) +
                (img.getRGB(x+1, y-1) & 0xff) + (img.getRGB(x+1, y) & 0xff) * 2 + (img.getRGB(x+1, y+1) & 0xff) / 4;
                
                //Vertical Edge Detection
                int vertPixel = (img.getRGB(x-1, y-1) & 0xff) + (img.getRGB(x, y-1) & 0xff) * 2 + (img.getRGB(x+1, y-1) & 0xff) +
                (img.getRGB(x-1, y+1) & 0xff) + (img.getRGB(x, y+1) & 0xff) * 2 + (img.getRGB(x+1, y+1) & 0xff) / 4;
                
                
                double pixel = Math.sqrt((double)(horPixel*horPixel + vertPixel*vertPixel));
                
                if (((int)(pixel) & 0xff) > 200){
                    pixel = 0xffffffff;
                } else {
                    pixel = 0;
                }
                
                edge.setRGB(x,y,(int)(pixel));
            }
        }
        
        
        return edge;
    }
    
    public static BufferedImage blur (BufferedImage img) {
        BufferedImage blurImg = new BufferedImage(
            img.getWidth()-2, img.getHeight()-2, BufferedImage.TYPE_BYTE_GRAY);
        int pix = 0;
        for (int y=0; y<blurImg.getHeight(); y++) {
            for (int x=0; x<blurImg.getWidth(); x++) {
                pix = (int)(4*(img.getRGB(x+1, y+1)& 0xFF)
                + 2*(img.getRGB(x+1, y)& 0xFF)
                + 2*(img.getRGB(x+1, y+2)& 0xFF)
                + 2*(img.getRGB(x, y+1)& 0xFF)
                + 2*(img.getRGB(x+2, y+1)& 0xFF)
                + (img.getRGB(x, y)& 0xFF)
                + (img.getRGB(x, y+2)& 0xFF)
                + (img.getRGB(x+2, y)& 0xFF)
                + (img.getRGB(x+2, y+2)& 0xFF))/16;
                int p = (255<<24) | (pix<<16) | (pix<<8) | pix; 
                blurImg.setRGB(x,y,p);
            }
        }
        return blurImg;
    }
    
    
    
    
    public static BufferedImage scaleMyself(BufferedImage img, int n){
        BufferedImage scale = new BufferedImage(
        img.getWidth()/n, img.getHeight()/n, BufferedImage.TYPE_INT_RGB);
        for(int x = 0; x< img.getWidth()-n; x+=n){
            for (int y = 0; y< img.getHeight()-n; y+=n){
                scale.setRGB(x/n, y/n, img.getRGB(x,y));
            }
        }
        return scale;
    }
    
    public static BufferedImage gaussianBlur(BufferedImage img){
        BufferedImage blurredImage = new BufferedImage(
        img.getWidth()-3, img.getHeight()-3, BufferedImage.TYPE_BYTE_GRAY);
        for (int x = 0; x< blurredImage.getWidth(); x++){
            for (int y = 0; y< blurredImage.getHeight(); y++){
                int rgb = (int)((img.getRGB(x+1, y+1) & 0xFF) * 6 +
                (img.getRGB(x+2, y+1) & 0xFF) * 6 +
                (img.getRGB(x+1, y+2) & 0xFF) * 6 +
                (img.getRGB(x+2, y+2) & 0xFF) * 6 +
                (img.getRGB(x+1, y) & 0xFF) * 3 +
                (img.getRGB(x+2, y) & 0xFF) * 3 +
                (img.getRGB(x, y+1) & 0xFF) * 3 +
                (img.getRGB(x, y+2) & 0xFF) * 3 +
                (img.getRGB(x+1, y + 3) & 0xFF) * 3 +
                (img.getRGB(x+2, y + 3) & 0xFF) * 3 +
                (img.getRGB(x+3, y + 1) & 0xFF) * 3 +
                (img.getRGB(x+3, y + 2) & 0xFF) * 3) / 48;
                int p = (255 << 24) | (rgb << 16) | (rgb << 8) | rgb;
                blurredImage.setRGB(x,y, p);
            }
        }
        
        return blurredImage;
    }
    
    public static BufferedImage rotationMyself(BufferedImage img){
        BufferedImage rotatedImage = new BufferedImage(
        img.getHeight(), img.getWidth(), BufferedImage.TYPE_INT_RGB);       
        for (int x = 0; x< img.getWidth(); x++){
            for (int y = 0; y<img.getHeight(); y++){
                rotatedImage.setRGB(y,x, img.getRGB(x, y));
            }
        }
        return rotatedImage;
    }
    
    public static BufferedImage pixelate(BufferedImage img, int scale){
        int rgb = 0;
        int p = 0;
        for (int x = 0; x<img.getWidth() - scale; x += scale){
            for(int y = 0; y <img.getHeight() - scale; y += scale){
                for(int a = 0; a < scale; a++){
                    for(int b = 0; b<scale; b++){
                        rgb += img.getRGB(x + a, y + b) & 0xff;
                    }
                }
                rgb = (int)(rgb / scale / scale);
                p = 255 << 24 | rgb << 16 | rgb << 8 | rgb;
                for (int a = 0; a < scale; a++){
                    for (int b = 0; b < scale; b++){
                        img.setRGB(x+a, y+b, p);
                    }
                }
            }
        }
        
        
        return img;
    }
    
    public static BufferedImage grayScale(BufferedImage img){
        BufferedImage grayScaledImage = new BufferedImage(img.getWidth(), img.getHeight(), BufferedImage.TYPE_BYTE_GRAY);
        Graphics g = grayScaledImage.getGraphics();
        g.drawImage(img, 0, 0, null);
        
        
        return grayScaledImage;
    }

    public static BufferedImage rotate(BufferedImage img, int rad){
        AffineTransform at = new AffineTransform();
        at.rotate(Math.toRadians(rad), img.getWidth(), img.getHeight());
        AffineTransformOp rotate = new AffineTransformOp(at, AffineTransformOp.TYPE_BILINEAR);
        return rotate.filter(img, null);
    }
    
    public static BufferedImage scale(BufferedImage img, double resc){
        AffineTransform at = new AffineTransform();
        at.scale(1/resc, 1/resc);
        AffineTransformOp scaleOp = new AffineTransformOp(at, AffineTransformOp.TYPE_BILINEAR);
        
        return scaleOp.filter(img, null);
    }
    
    public static void display(BufferedImage img){
        JFrame frame = new JFrame("image");
        JLabel label = new JLabel(new ImageIcon(img));
        frame.getContentPane().add(label);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);
    }
}