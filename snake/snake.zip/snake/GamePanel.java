import java.awt.event.*;
import javax.swing.*;
import java.awt.*;
import java.util.Random;


public class GamePanel extends JPanel implements ActionListener{
    private static int width= 600;
    private static int height = 600;
    private static int unit = 50;
    private static int game_units = (width*height)/unit;
    private static int delay =90;
    private int x[] = new int[game_units];
    private int y[] = new int[game_units];
    int bodyparts = 5;
    int applesEaten = 0;
    int appleX;
    int appleY;
    char direction = 'R';
    boolean running = false;
    Timer timer;
    Random random;
    
    
    GamePanel(){
        random = new Random();
        this.setPreferredSize(new Dimension(width, height));
        this.setBackground(Color.black);
        this.setFocusable(true);
        this.addKeyListener(new keyAdapter());
        startGame();
        
    }
    
    public void startGame(){
        newApple();
        running = true;
        Timer timer = new Timer(delay, this);
        timer.start();
    }
    
    public void paintComponent(Graphics g){
        super.paintComponent(g);
        draw(g);
    }
    
    public void draw(Graphics g){
        for(int x = 0; x<width; x+= unit){
            g.setColor(Color.white);
            g.drawLine(x,0,x, height);
            g.drawLine(0,x,width,x);
        }
        /*
        for (int i = 0; i*unit < width; i++){
            g.drawLine(i*unit, 0, i*unit, height);
            g.drawLine(0, i*unit, width, i*unit);
        }*/
        
        g.setColor(Color.red);
        g.fillOval(appleX, appleY, unit, unit);
        
        for (int i = 0; i<bodyparts ; i++){
            //g.setColor(new Color(random.nextInt(255),random.nextInt(255),random.nextInt(255)));
            if (i == 0){
                g.setColor(new Color(160, 255, 0));
                g.fillRect(x[0],y[0], unit, unit);
            }
            
            else{
                g.setColor(Color.green);
                g.fillRect(x[i],y[i], unit, unit);
            }
        }    
        
        g.setFont(new Font("Serif", Font.BOLD, 20));
        g.setColor(Color.red);
        g.drawString("Score:" + applesEaten, (width - g.getFontMetrics().stringWidth("Score" + applesEaten))/2, unit);
        
    }
    
    public void gameOver(){
        if (!running){
            x[0] = random.nextInt((int)(width/unit))*unit;
            y[0] = random.nextInt((int)(height/unit))*unit;
            running = true;
            applesEaten--;
            if (applesEaten < 0){
                running = false;
            }
        
        }
    }
    
    public void newApple(){
        appleX = random.nextInt((int)(width/unit))*unit;
        appleY = random.nextInt((int)(height/unit))*unit;
        
    }
    
    public void checkApples(){
        if (x[0] == appleX && y[0] == appleY){
            //bodyparts++;
            newApple();
            applesEaten++;
            x[0] = random.nextInt(((int)((width - unit)/unit))) * unit;
            y[0] = random.nextInt(((int)((height - unit)/unit))) * unit;
        }
    }
    
    public void checkCollision(){
        if (x[0] >= width || x[0] < 0 || y[0] >= height || y[0] < 0){
            running = false;
            gameOver();
        }
        for (int i = 1; i<bodyparts ; i++){
            if (x[i] == x[0] && y[i] == y[0]){
                running = false;
                gameOver();
            }
        }
    }
    
    public void move(){
        for (int i = bodyparts; i>0; i--){
            x[i] = x[i-1];
            y[i] = y[i-1];
        }
        
        switch (direction){
            case 'U':
                y[0] = y[0] - unit;
                break;
            case 'D':
                y[0] = y[0] + unit;
                break;
            case 'R':
                x[0] = x[0] + unit;
                break;
            case 'L':
                x[0] = x[0] - unit;
                break;
        }
    }
    
    @Override
    public void actionPerformed(ActionEvent e){
        if (running){
            move();
            checkApples();
            checkCollision();
        }
        repaint();
    }
    
    public class keyAdapter extends KeyAdapter{
        @Override
        public void keyPressed(KeyEvent e){
            int key = e.getKeyCode();
            if (key == KeyEvent.VK_LEFT && direction != 'R'){
                direction = 'L';
            }
            if (key == KeyEvent.VK_RIGHT && direction != 'L'){
                direction = 'R';
            }
            if (key == KeyEvent.VK_UP && direction != 'D'){
                direction = 'U';
            }
            if (key == KeyEvent.VK_DOWN && direction != 'U'){
                direction = 'D';
            }
            if (key == KeyEvent.VK_ENTER){
                x[0] = 0;
                y[0] = 0;
                applesEaten = 0;
                direction = 'R';
                running = true;
            }
            
        }
    }
}